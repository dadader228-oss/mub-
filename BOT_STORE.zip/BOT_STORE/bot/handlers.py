from __future__ import annotations

import logging
from datetime import datetime, timezone

from aiogram import F, Router, Bot
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    CallbackQuery,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    SuccessfulPayment,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from sqlalchemy import select, desc, func

from config import get_settings
from database.session import async_session
from database.models import (
    Order, Payment, OrderStatus, PaymentMethod, User, Product,
    Ticket, TicketStatus,
)
from services.order_service import get_or_create_user, mark_order_paid
from services.telegram_auth import is_admin
from services.delivery import deliver_order
from bot.keyboards import main_menu_kb, admin_menu_kb

logger = logging.getLogger(__name__)
router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    async with async_session() as session:
        await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name,
            language_code=message.from_user.language_code,
        )
        await session.commit()

    text = (
        "Добро пожаловать в <b>BOT STORE</b>!\n\n"
        "Магазин готовых Telegram-ботов, VPN-решений и индивидуальной разработки.\n\n"
        "Выбирай подходящий продукт и оформляй заказ прямо здесь."
    )
    await message.answer(text, reply_markup=main_menu_kb(), parse_mode="HTML")


@router.message(Command("admin"))
async def cmd_admin(message: Message) -> None:
    if not is_admin(message.from_user.id):
        await message.answer("Доступ запрещён.")
        return
    await message.answer("🛠 <b>Админ-панель BOT STORE</b>", reply_markup=admin_menu_kb(), parse_mode="HTML")


@router.callback_query(F.data == "about")
async def cb_about(callback: CallbackQuery) -> None:
    await callback.answer()
    await callback.message.answer(
        "<b>BOT STORE</b>\n\n"
        "Магазин готовых Telegram-ботов, VPN, исходного кода и услуг разработки.\n"
        "Оплата: Telegram Stars ⭐ и рубли ₽.\n"
        "Поддержка — через раздел «Поддержка» или этот чат.",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "profile")
async def cb_profile(callback: CallbackQuery) -> None:
    await callback.answer()
    user = callback.from_user
    async with async_session() as session:
        db = await get_or_create_user(session, user.id, user.username, user.first_name, user.last_name)
        await session.commit()
        await callback.message.answer(
            f"👤 <b>Профиль</b>\n"
            f"ID: <code>{user.id}</code>\n"
            f"Имя: {user.full_name}\n"
            f"Username: @{user.username or '—'}\n"
            f"Баланс: {db.balance} ₽\n"
            f"Регистрация: {db.created_at.strftime('%d.%m.%Y') if db.created_at else '—'}",
            parse_mode="HTML",
        )


@router.callback_query(F.data == "orders")
async def cb_orders(callback: CallbackQuery) -> None:
    await callback.answer()
    async with async_session() as session:
        db = await get_or_create_user(session, callback.from_user.id)
        r = await session.execute(
            select(Order).where(Order.user_id == db.id).order_by(desc(Order.created_at)).limit(10)
        )
        orders = r.scalars().all()
    if not orders:
        await callback.message.answer("📦 Заказов пока нет.\nОткройте магазин и выберите товар.")
        return
    lines = ["📦 <b>Ваши заказы:</b>\n"]
    for o in orders:
        lines.append(
            f"• <code>{o.order_number}</code> — {o.status}\n"
            f"  {o.total_stars}⭐ / {o.total_rub}₽"
        )
    await callback.message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "support")
async def cb_support(callback: CallbackQuery) -> None:
    await callback.answer()
    await callback.message.answer(
        "🎫 <b>Поддержка</b>\n\n"
        "Создайте обращение в Mini App → «Поддержка»\n"
        "или просто напишите сообщение сюда — администратор ответит.",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "bonuses")
async def cb_bonuses(callback: CallbackQuery) -> None:
    await callback.answer()
    await callback.message.answer(
        "🎁 <b>Бонусы</b>\n\n"
        "• Реферальная программа — в профиле Mini App\n"
        "• Промокоды — при оформлении заказа\n"
        "• Акции — следите за уведомлениями",
        parse_mode="HTML",
    )


@router.pre_checkout_query()
async def process_pre_checkout(pre_checkout: PreCheckoutQuery) -> None:
    payload = pre_checkout.invoice_payload
    try:
        parts = payload.split(":")
        order_id = int(parts[1])
    except (IndexError, ValueError):
        await pre_checkout.answer(ok=False, error_message="Некорректный заказ")
        return

    async with async_session() as session:
        order = await session.get(Order, order_id)
        if not order:
            await pre_checkout.answer(ok=False, error_message="Заказ не найден")
            return
        if order.status != OrderStatus.PENDING_PAYMENT.value:
            await pre_checkout.answer(ok=False, error_message="Заказ уже обработан")
            return
        if pre_checkout.currency != "XTR":
            await pre_checkout.answer(ok=False, error_message="Неверная валюта")
            return
        if pre_checkout.total_amount != order.total_stars:
            await pre_checkout.answer(ok=False, error_message="Сумма не совпадает")
            return

    await pre_checkout.answer(ok=True)


@router.message(F.successful_payment)
async def process_successful_payment(message: Message, bot: Bot) -> None:
    sp: SuccessfulPayment = message.successful_payment
    payload = sp.invoice_payload
    try:
        parts = payload.split(":")
        order_id = int(parts[1])
    except (IndexError, ValueError):
        await message.answer("Ошибка обработки платежа. Обратитесь в поддержку.")
        return

    async with async_session() as session:
        existing = await session.execute(
            select(Payment).where(Payment.telegram_payment_charge_id == sp.telegram_payment_charge_id)
        )
        if existing.scalar_one_or_none():
            await message.answer("Платёж уже обработан.")
            return

        order = await session.get(Order, order_id)
        if not order:
            await message.answer("Заказ не найден.")
            return

        payment = Payment(
            order_id=order.id,
            method=PaymentMethod.STARS.value,
            amount_stars=sp.total_amount,
            currency=sp.currency,
            status="succeeded",
            telegram_payment_charge_id=sp.telegram_payment_charge_id,
            provider_payment_charge_id=sp.provider_payment_charge_id,
            payload=payload,
            confirmed_at=datetime.now(timezone.utc),
        )
        session.add(payment)
        await mark_order_paid(session, order, payment)
        await session.commit()

        try:
            await deliver_order(session, bot, order)
            await session.commit()
        except Exception as e:
            logger.exception("Delivery failed: %s", e)

    await message.answer(
        f"✅ <b>Оплата прошла успешно!</b>\n"
        f"Заказ <code>{order.order_number}</code>\n"
        f"Сумма: {sp.total_amount} ⭐\n\n"
        f"Товар отправлен или передан в обработку.",
        parse_mode="HTML",
    )


async def send_stars_invoice(bot: Bot, chat_id: int, order: Order, title: str, description: str):
    prices = [LabeledPrice(label=title[:32], amount=order.total_stars)]
    payload = f"order:{order.id}:{order.order_number}"
    await bot.send_invoice(
        chat_id=chat_id,
        title=title[:32],
        description=description[:255],
        payload=payload,
        currency="XTR",
        prices=prices,
        provider_token="",
    )


@router.callback_query(F.data == "admin:stats")
async def admin_stats(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    async with async_session() as session:
        users = (await session.execute(select(func.count(User.id)))).scalar() or 0
        orders = (await session.execute(select(func.count(Order.id)))).scalar() or 0
        paid = (await session.execute(
            select(func.count(Order.id)).where(
                Order.status.in_([
                    OrderStatus.PAID.value, OrderStatus.PROCESSING.value,
                    OrderStatus.COMPLETED.value, OrderStatus.READY.value,
                ])
            )
        )).scalar() or 0
        revenue = (await session.execute(
            select(func.coalesce(func.sum(Order.total_rub), 0)).where(
                Order.status.in_([OrderStatus.PAID.value, OrderStatus.COMPLETED.value, OrderStatus.PROCESSING.value])
            )
        )).scalar() or 0
    await callback.message.answer(
        f"📊 <b>Статистика</b>\n\n"
        f"Пользователи: {users}\n"
        f"Заказы: {orders}\n"
        f"Оплаченные: {paid}\n"
        f"Выручка: {revenue} ₽",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:orders")
async def admin_orders(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    async with async_session() as session:
        r = await session.execute(
            select(Order).order_by(desc(Order.created_at)).limit(15)
        )
        orders = r.scalars().all()
    if not orders:
        await callback.message.answer("Заказов нет.")
        return
    lines = ["📦 <b>Последние заказы:</b>\n"]
    kb_rows = []
    for o in orders:
        lines.append(f"• <code>{o.order_number}</code> [{o.status}] {o.total_rub}₽ / {o.total_stars}⭐")
        if o.status == OrderStatus.AWAITING_PAYMENT_CHECK.value:
            kb_rows.append([
                InlineKeyboardButton(text=f"✅ {o.order_number}", callback_data=f"admin:pay_ok:{o.id}"),
                InlineKeyboardButton(text=f"❌ {o.order_number}", callback_data=f"admin:pay_no:{o.id}"),
            ])
    kb = InlineKeyboardMarkup(inline_keyboard=kb_rows) if kb_rows else None
    await callback.message.answer("\n".join(lines), parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("admin:pay_ok:"))
async def admin_pay_ok(callback: CallbackQuery, bot: Bot) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    order_id = int(callback.data.split(":")[2])
    async with async_session() as session:
        order = await session.get(Order, order_id)
        if not order or order.status != OrderStatus.AWAITING_PAYMENT_CHECK.value:
            await callback.answer("Уже обработан или не найден", show_alert=True)
            return
        payment = Payment(
            order_id=order.id,
            method=PaymentMethod.RUB.value,
            amount_rub=order.total_rub,
            currency="RUB",
            status="succeeded",
            confirmed_by=callback.from_user.id,
            confirmed_at=datetime.now(timezone.utc),
        )
        session.add(payment)
        await mark_order_paid(session, order, payment)
        await session.commit()
        try:
            await deliver_order(session, bot, order)
            await session.commit()
        except Exception as e:
            logger.exception(e)
        user = await session.get(User, order.user_id)
        if user:
            await bot.send_message(
                user.telegram_id,
                f"✅ Оплата заказа <code>{order.order_number}</code> подтверждена администратором.\n"
                f"Товар выдан или передан в работу.",
                parse_mode="HTML",
            )
    await callback.answer("Подтверждено")
    await callback.message.answer(f"✅ Заказ {order.order_number} — оплата подтверждена.")


@router.callback_query(F.data.startswith("admin:pay_no:"))
async def admin_pay_no(callback: CallbackQuery, bot: Bot) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    order_id = int(callback.data.split(":")[2])
    async with async_session() as session:
        order = await session.get(Order, order_id)
        if not order:
            await callback.answer("Не найден", show_alert=True)
            return
        order.status = OrderStatus.CANCELLED.value
        order.admin_note = "Отклонено администратором"
        await session.commit()
        user = await session.get(User, order.user_id)
        if user:
            await bot.send_message(
                user.telegram_id,
                f"❌ Оплата заказа <code>{order.order_number}</code> отклонена.\n"
                f"Обратитесь в поддержку при необходимости.",
                parse_mode="HTML",
            )
    await callback.answer("Отклонено")
    await callback.message.answer("❌ Заказ отклонён.")


@router.callback_query(F.data == "admin:rub_payments")
async def admin_rub(callback: CallbackQuery) -> None:
    await admin_orders(callback)


@router.callback_query(F.data == "admin:stars")
async def admin_stars(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    async with async_session() as session:
        r = await session.execute(
            select(Payment).where(Payment.method == PaymentMethod.STARS.value)
            .order_by(desc(Payment.created_at)).limit(15)
        )
        pays = r.scalars().all()
    if not pays:
        await callback.message.answer("Stars-платежей пока нет.")
        return
    lines = ["⭐ <b>Последние Stars-платежи:</b>\n"]
    for p in pays:
        lines.append(f"• Order #{p.order_id} — {p.amount_stars} XTR — {p.status}")
    await callback.message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "admin:products")
async def admin_products(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    async with async_session() as session:
        r = await session.execute(select(Product).order_by(desc(Product.id)).limit(20))
        products = r.scalars().all()
    if not products:
        await callback.message.answer("Товаров нет. Добавьте через API или seed.")
        return
    lines = ["🛍 <b>Товары:</b>\n"]
    for p in products:
        status = "✅" if p.is_active else "🚫"
        lines.append(f"{status} [{p.id}] {p.name} — {p.price_stars}⭐ / {p.price_rub}₽")
    await callback.message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "admin:tickets")
async def admin_tickets(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    async with async_session() as session:
        r = await session.execute(
            select(Ticket).where(Ticket.status != TicketStatus.CLOSED.value)
            .order_by(desc(Ticket.updated_at)).limit(15)
        )
        tickets = r.scalars().all()
    if not tickets:
        await callback.message.answer("Открытых тикетов нет.")
        return
    lines = ["🎫 <b>Открытые тикеты:</b>\n"]
    for t in tickets:
        lines.append(f"• <code>{t.ticket_number}</code> — {t.subject} [{t.status}]")
    await callback.message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "admin:broadcast")
async def admin_broadcast(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    await callback.message.answer(
        "📢 Рассылка: отправьте боту команду\n"
        "<code>/broadcast Текст сообщения</code>",
        parse_mode="HTML",
    )


@router.message(Command("broadcast"))
async def cmd_broadcast(message: Message, bot: Bot) -> None:
    if not is_admin(message.from_user.id):
        return
    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.answer("Использование: /broadcast Текст")
        return
    body = text[1]
    async with async_session() as session:
        r = await session.execute(select(User.telegram_id))
        ids = [row[0] for row in r.all()]
    ok, fail = 0, 0
    for tid in ids:
        try:
            await bot.send_message(tid, body, parse_mode="HTML")
            ok += 1
        except Exception:
            fail += 1
    await message.answer(f"Рассылка завершена.\nУспешно: {ok}\nОшибок: {fail}")


@router.callback_query(F.data == "admin:settings")
async def admin_settings(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return
    await callback.answer()
    await callback.message.answer(
        "⚙️ Настройки\n\n"
        "Инструкции по оплате ₽ — через API:\n"
        "POST /api/admin/settings/payment_instructions"
    )


@router.message(Command("pay"))
async def cmd_pay_stars(message: Message, bot: Bot) -> None:
    if not is_admin(message.from_user.id):
        return
    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("Usage: /pay ORDER_ID")
        return
    try:
        order_id = int(parts[1])
    except ValueError:
        await message.answer("Invalid ID")
        return
    async with async_session() as session:
        order = await session.get(Order, order_id)
        if not order:
            await message.answer("Order not found")
            return
        user = await session.get(User, order.user_id)
        if not user:
            await message.answer("User not found")
            return
        await send_stars_invoice(
            bot, user.telegram_id, order,
            title=f"Заказ {order.order_number}",
            description=f"Оплата заказа {order.order_number}",
        )
    await message.answer("Invoice sent.")
