from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo, ReplyKeyboardMarkup, KeyboardButton
from config import get_settings


def main_menu_kb() -> InlineKeyboardMarkup:
    settings = get_settings()
    webapp = WebAppInfo(url=settings.WEBAPP_URL)

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🛍️ Открыть магазин", web_app=webapp)],
            [
                InlineKeyboardButton(text="📦 Мои заказы", callback_data="orders"),
                InlineKeyboardButton(text="👤 Профиль", callback_data="profile"),
            ],
            [
                InlineKeyboardButton(text="🎫 Поддержка", callback_data="support"),
                InlineKeyboardButton(text="🎁 Бонусы", callback_data="bonuses"),
            ],
            [InlineKeyboardButton(text="ℹ️ О проекте", callback_data="about")],
        ]
    )


def admin_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Статистика", callback_data="admin:stats")],
            [
                InlineKeyboardButton(text="🛍 Товары", callback_data="admin:products"),
                InlineKeyboardButton(text="📦 Заказы", callback_data="admin:orders"),
            ],
            [
                InlineKeyboardButton(text="💳 Платежи ₽", callback_data="admin:rub_payments"),
                InlineKeyboardButton(text="⭐ Stars", callback_data="admin:stars"),
            ],
            [
                InlineKeyboardButton(text="🎫 Тикеты", callback_data="admin:tickets"),
                InlineKeyboardButton(text="📢 Рассылка", callback_data="admin:broadcast"),
            ],
            [InlineKeyboardButton(text="⚙️ Настройки", callback_data="admin:settings")],
        ]
    )
