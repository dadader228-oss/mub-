"""Simple notification helpers."""
from __future__ import annotations

import logging
from typing import Optional

from aiogram import Bot
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import Notification, User
from config import get_settings

logger = logging.getLogger(__name__)


async def notify_user(
    session: AsyncSession,
    bot: Optional[Bot],
    user_id: int,
    title: str,
    body: str,
    ntype: str = "system",
    related_id: Optional[int] = None,
    send_telegram: bool = True,
) -> None:
    n = Notification(
        user_id=user_id,
        title=title,
        body=body,
        type=ntype,
        related_id=related_id,
    )
    session.add(n)
    await session.flush()

    if send_telegram and bot:
        user = await session.get(User, user_id)
        if user:
            try:
                await bot.send_message(
                    user.telegram_id,
                    f"<b>{title}</b>\n{body}",
                    parse_mode="HTML",
                )
            except Exception as e:
                logger.warning("TG notify failed: %s", e)


async def notify_admins(bot: Bot, text: str) -> None:
    settings = get_settings()
    for admin_id in settings.admin_ids:
        try:
            await bot.send_message(admin_id, text, parse_mode="HTML")
        except Exception as e:
            logger.warning("Admin notify %s failed: %s", admin_id, e)
