"""Product delivery: AUTO (file/link) and MANUAL (admin)."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from aiogram import Bot
from aiogram.types import FSInputFile
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from sqlalchemy import select

from database.models import Order, OrderItem, OrderStatus, Product, DeliveryMode

logger = logging.getLogger(__name__)
STORAGE = Path("storage/uploads")


async def deliver_order(session: AsyncSession, bot: Bot, order: Order) -> None:
    """
    After payment confirmation:
    - AUTO items → send files / instructions immediately
    - MANUAL items → notify admins, set status processing
    """
    result = await session.execute(
        select(Order)
        .options(selectinload(Order.items).selectinload(OrderItem.product))
        .where(Order.id == order.id)
    )
    order = result.scalar_one()

    has_manual = False
    has_auto = False

    for item in order.items:
        product = item.product
        if not product:
            continue

        if item.delivery_mode == DeliveryMode.AUTO.value or (
            product and product.delivery_mode == DeliveryMode.AUTO.value
        ):
            has_auto = True
            await _deliver_auto(bot, order, item, product)
        else:
            has_manual = True

    if has_manual and not has_auto:
        order.status = OrderStatus.PROCESSING.value
    elif has_auto and not has_manual:
        order.status = OrderStatus.COMPLETED.value
        order.completed_at = order.paid_at
    else:
        order.status = OrderStatus.PROCESSING.value  # mixed

    await session.flush()

    # Notify user
    try:
        from database.models import User
        user = await session.get(User, order.user_id)
        if user:
            text = (
                f"✅ Заказ <b>{order.order_number}</b> обработан.\n"
            )
            if has_auto:
                text += "Цифровые товары отправлены выше.\n"
            if has_manual:
                text += "Услуги/ручная выдача — администратор свяжется или выполнит работу.\n"
            await bot.send_message(user.telegram_id, text, parse_mode="HTML")
    except Exception as e:
        logger.exception("Notify user failed: %s", e)


async def _deliver_auto(
    bot: Bot, order: Order, item: OrderItem, product: Product
) -> None:
    chat_id = None
    # We need telegram_id — resolve via order.user
    from database.session import async_session
    from database.models import User

    async with async_session() as s:
        user = await s.get(User, order.user_id)
        if not user:
            return
        chat_id = user.telegram_id

    caption = (
        f"📦 Товар: <b>{product.name}</b>\n"
        f"Заказ: {order.order_number}\n"
    )
    if product.guarantee_days:
        caption += f"Гарантия: {product.guarantee_days} дн.\n"

    # Prefer file if exists
    if product.file_path:
        path = Path(product.file_path)
        if not path.is_absolute():
            path = STORAGE / path
        if path.exists():
            try:
                await bot.send_document(
                    chat_id,
                    FSInputFile(path),
                    caption=caption,
                    parse_mode="HTML",
                )
                return
            except Exception as e:
                logger.exception("Send file failed: %s", e)

    # Fallback: description / demo link
    text = caption + "\n" + (product.description or "")[:3000]
    if product.demo_url:
        text += f"\n\n🔗 {product.demo_url}"
    await bot.send_message(chat_id, text, parse_mode="HTML")
