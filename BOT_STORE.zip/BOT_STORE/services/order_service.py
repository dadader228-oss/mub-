from __future__ import annotations

import secrets
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import (
    Cart,
    CartItem,
    Order,
    OrderItem,
    OrderStatus,
    Payment,
    PaymentMethod,
    Product,
    User,
)


def generate_order_number() -> str:
    return f"BS-{secrets.token_hex(4).upper()}-{secrets.token_hex(2).upper()}"


async def get_or_create_user(
    session: AsyncSession,
    telegram_id: int,
    username: Optional[str] = None,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    language_code: Optional[str] = None,
) -> User:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    user = result.scalar_one_or_none()
    if user:
        # soft update
        if username is not None:
            user.username = username
        if first_name is not None:
            user.first_name = first_name
        if last_name is not None:
            user.last_name = last_name
        return user

    user = User(
        telegram_id=telegram_id,
        username=username,
        first_name=first_name,
        last_name=last_name,
        language_code=language_code,
    )
    session.add(user)
    await session.flush()
    return user


async def get_or_create_cart(session: AsyncSession, user: User) -> Cart:
    result = await session.execute(
        select(Cart).options(selectinload(Cart.items)).where(Cart.user_id == user.id)
    )
    cart = result.scalar_one_or_none()
    if cart:
        return cart
    cart = Cart(user_id=user.id)
    session.add(cart)
    await session.flush()
    return cart


async def create_order_from_cart(
    session: AsyncSession,
    user: User,
    payment_method: str,
    promo_code: Optional[str] = None,
) -> Order:
    cart = await get_or_create_cart(session, user)
    if not cart.items:
        raise ValueError("Cart is empty")

    total_rub = Decimal("0.00")
    total_stars = 0
    order_items: list[OrderItem] = []

    for item in cart.items:
        product = await session.get(Product, item.product_id)
        if not product or not product.is_active:
            raise ValueError(f"Product {item.product_id} unavailable")
        if product.stock == 0:
            raise ValueError(f"Product {product.name} out of stock")

        total_rub += product.price_rub * item.quantity
        total_stars += product.price_stars * item.quantity

        order_items.append(
            OrderItem(
                product_id=product.id,
                product_name=product.name,
                price_rub=product.price_rub,
                price_stars=product.price_stars,
                quantity=item.quantity,
                delivery_mode=product.delivery_mode,
            )
        )

    order = Order(
        order_number=generate_order_number(),
        user_id=user.id,
        status=OrderStatus.PENDING_PAYMENT.value,
        payment_method=payment_method,
        total_rub=total_rub,
        total_stars=total_stars,
        promo_code=promo_code,
    )
    session.add(order)
    await session.flush()

    for oi in order_items:
        oi.order_id = order.id
        session.add(oi)

    # clear cart
    for item in list(cart.items):
        await session.delete(item)

    await session.flush()
    return order


async def mark_order_paid(
    session: AsyncSession,
    order: Order,
    payment: Payment,
) -> None:
    """Idempotent mark as paid. Call only after successful_payment verification."""
    if order.status in (
        OrderStatus.PAID.value,
        OrderStatus.PROCESSING.value,
        OrderStatus.READY.value,
        OrderStatus.COMPLETED.value,
    ):
        return  # already processed

    order.status = OrderStatus.PAID.value
    order.paid_at = datetime.now(timezone.utc)
    payment.status = "succeeded"
    payment.confirmed_at = datetime.now(timezone.utc)
    await session.flush()
