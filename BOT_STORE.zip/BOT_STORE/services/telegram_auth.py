"""
Validation of Telegram Mini App initData according to official docs.
Never trust client-side data.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any, Dict, Optional
from urllib.parse import parse_qsl

from config import get_settings


class InitDataError(Exception):
    pass


def validate_init_data(init_data: str, bot_token: Optional[str] = None) -> Dict[str, Any]:
    """
    Validates Telegram WebApp initData.
    Raises InitDataError on failure.
    Returns parsed user data and other fields.
    """
    settings = get_settings()
    token = bot_token or settings.BOT_TOKEN
    max_age = settings.INIT_DATA_MAX_AGE

    if not init_data:
        raise InitDataError("Empty initData")

    parsed = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise InitDataError("Missing hash")

    # Build data-check-string
    data_check_arr = [f"{k}={v}" for k, v in sorted(parsed.items())]
    data_check_string = "\n".join(data_check_arr)

    secret_key = hmac.new(
        b"WebAppData", token.encode(), hashlib.sha256
    ).digest()
    calculated_hash = hmac.new(
        secret_key, data_check_string.encode(), hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(calculated_hash, received_hash):
        raise InitDataError("Invalid signature")

    # Check auth_date
    auth_date = int(parsed.get("auth_date", 0))
    if time.time() - auth_date > max_age:
        raise InitDataError("initData expired")

    # Parse user
    user_raw = parsed.get("user")
    user = json.loads(user_raw) if user_raw else None

    return {
        "user": user,
        "auth_date": auth_date,
        "query_id": parsed.get("query_id"),
        "chat_instance": parsed.get("chat_instance"),
        "chat_type": parsed.get("chat_type"),
        "start_param": parsed.get("start_param"),
        "raw": parsed,
    }


def is_admin(telegram_id: int) -> bool:
    settings = get_settings()
    return telegram_id in settings.admin_ids
